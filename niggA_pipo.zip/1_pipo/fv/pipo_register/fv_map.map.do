
//input ports
add mapped point clk clk -type PI PI
add mapped point rst_n rst_n -type PI PI
add mapped point en en -type PI PI
add mapped point d[7] d[7] -type PI PI
add mapped point d[6] d[6] -type PI PI
add mapped point d[5] d[5] -type PI PI
add mapped point d[4] d[4] -type PI PI
add mapped point d[3] d[3] -type PI PI
add mapped point d[2] d[2] -type PI PI
add mapped point d[1] d[1] -type PI PI
add mapped point d[0] d[0] -type PI PI

//output ports
add mapped point q[7] q[7] -type PO PO
add mapped point q[6] q[6] -type PO PO
add mapped point q[5] q[5] -type PO PO
add mapped point q[4] q[4] -type PO PO
add mapped point q[3] q[3] -type PO PO
add mapped point q[2] q[2] -type PO PO
add mapped point q[1] q[1] -type PO PO
add mapped point q[0] q[0] -type PO PO

//inout ports




//Sequential Pins
add mapped point q[0]/q q_reg[0]/Q -type DFF DFF
add mapped point q[2]/q q_reg[2]/Q -type DFF DFF
add mapped point q[3]/q q_reg[3]/Q -type DFF DFF
add mapped point q[4]/q q_reg[4]/Q -type DFF DFF
add mapped point q[5]/q q_reg[5]/Q -type DFF DFF
add mapped point q[1]/q q_reg[1]/Q -type DFF DFF
add mapped point q[6]/q q_reg[6]/Q -type DFF DFF
add mapped point q[7]/q q_reg[7]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
