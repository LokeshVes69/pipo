`timescale 1ns / 1ps

module tb_pipo_register;

    // Parameters
    localparam WIDTH = 8;

    // Testbench Signals
    reg              clk;
    reg              rst_n;
    reg              en;
    reg  [WIDTH-1:0] d;
    wire [WIDTH-1:0] q;

    // Instantiate the Device Under Test (DUT)
    pipo_register #(
        .WIDTH(WIDTH)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .en(en),
        .d(d),
        .q(q)
    );

    // Clock Generation (100 MHz)
    initial begin
        clk = 0;
        forever #5 clk = ~clk; 
    end

    // Test Sequence
    initial begin
        // Note for Xcelium: You can also use $shm_open("waves.shm") and 
        // $shm_probe("AS") if you prefer Cadence SimVision format over VCD.
        $dumpfile("dump.vcd");
        $dumpvars(0, tb_pipo_register);

        // 1. Initialization
        rst_n = 0;
        en    = 0;
        d     = 8'h00;

        // 2. Release Reset
        #15;
        rst_n = 1;
        $display("--- Reset Released ---");

        // 3. Write Data with Enable HIGH
        #10;
        en = 1;
        d  = 8'hAA; 
        #10; // Wait a clock cycle to see data at Q

        // 4. Change Data with Enable HIGH
        d  = 8'h55;
        #10;

        // 5. Change Data with Enable LOW (Should Hold Previous State: 55)
        en = 0;
        d  = 8'hFF;
        $display("--- Testing Enable Hold ---");
        #20;

        // 6. Test Asynchronous Reset during operation
        en = 1;
        d  = 8'hCC;
        #7; // Assert reset asynchronously (not on clock edge)
        rst_n = 0;
        $display("--- Asserting Async Reset ---");
        #5;
        rst_n = 1;

        // End Simulation
        #20;
        $display("--- Simulation Complete ---");
        $finish;
    end

    // Console Monitor
    initial begin
        $monitor("Time: %0t | rst_n: %b | en: %b | d: %h | q: %h", 
                 $time, rst_n, en, d, q);
    end

endmodule
