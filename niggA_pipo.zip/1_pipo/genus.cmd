# Cadence Genus(TM) Synthesis Solution, Version 21.14-s082_1, built Jun 23 2022 14:32:08

# Date: Thu Apr 16 08:31:41 2026
# Host: vesit.ves.ac.in (x86_64 w/Linux 4.18.0-425.19.2.el8_7.x86_64) (10cores*16cpus*1physical cpu*Intel(R) Core(TM) i5-14400 20480KB)
# OS:   Red Hat Enterprise Linux release 8.7 (Ootpa)

read_lib /home/install/FOUNDRY/digital/180nm/dig/lib/slow.lib
read_hdl pipo.v
elaborate pipo_register
read_sdc constraints.sdc
syn_gen
syn_map
syn_opt
report_area > area.rpt
report_power.rpt
report_power > power.rpt
report_timing > timing.rpt
write_hdl pipo_synth.v
write_hdl > pipo_synth.v
write_sdc > pipo_synth.sdc
exit
