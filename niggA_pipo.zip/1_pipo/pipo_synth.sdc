# ####################################################################

#  Created by Genus(TM) Synthesis Solution 21.14-s082_1 on Thu Apr 16 08:41:29 IST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design pipo_register

create_clock -name "clk" -period 10.0 -waveform {0.0 5.0} [get_ports clk]
set_clock_transition 0.15 [get_clocks clk]
set_load -pin_load 0.05 [get_ports {q[7]}]
set_load -pin_load 0.05 [get_ports {q[6]}]
set_load -pin_load 0.05 [get_ports {q[5]}]
set_load -pin_load 0.05 [get_ports {q[4]}]
set_load -pin_load 0.05 [get_ports {q[3]}]
set_load -pin_load 0.05 [get_ports {q[2]}]
set_load -pin_load 0.05 [get_ports {q[1]}]
set_load -pin_load 0.05 [get_ports {q[0]}]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {d[7]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {d[6]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {d[5]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {d[4]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {d[3]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {d[2]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {d[1]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {d[0]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports en]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {d[7]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {d[6]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {d[5]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {d[4]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {d[3]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {d[2]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {d[1]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {d[0]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports en]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports rst_n]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {q[7]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {q[6]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {q[5]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {q[4]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {q[3]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {q[2]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {q[1]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {q[0]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {q[7]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {q[6]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {q[5]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {q[4]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {q[3]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {q[2]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {q[1]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.5 [get_ports {q[0]}]
set_input_transition 0.2 [get_ports rst_n]
set_input_transition 0.2 [get_ports en]
set_input_transition 0.2 [get_ports {d[7]}]
set_input_transition 0.2 [get_ports {d[6]}]
set_input_transition 0.2 [get_ports {d[5]}]
set_input_transition 0.2 [get_ports {d[4]}]
set_input_transition 0.2 [get_ports {d[3]}]
set_input_transition 0.2 [get_ports {d[2]}]
set_input_transition 0.2 [get_ports {d[1]}]
set_input_transition 0.2 [get_ports {d[0]}]
set_wire_load_mode "enclosed"
set_clock_uncertainty -setup 0.2 [get_clocks clk]
set_clock_uncertainty -hold 0.1 [get_clocks clk]
