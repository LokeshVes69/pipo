`timescale 1ns / 1ps

module pipo_register #(
    parameter WIDTH = 8 // Parameterized width, default is 8-bit
) (
    input  wire             clk,    // Clock
    input  wire             rst_n,  // Active-low asynchronous reset
    input  wire             en,     // Clock enable
    input  wire [WIDTH-1:0] d,      // Parallel Data Input
    output reg  [WIDTH-1:0] q       // Parallel Data Output
);

    // Standard synchronous block with asynchronous reset
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Reset state: Clear the register to 0
            q <= {WIDTH{1'b0}};
        end else if (en) begin
            // Active state: Latch the parallel input data
            q <= d;
        end
        // If enable is low, it naturally holds its previous state
    end

endmodule
