# ==============================================================================
# SDC File for PIPO Register
# Target Frequency: 100 MHz (Period = 10.0 ns)
# ==============================================================================

# ------------------------------------------------------------------------------
# 1. Clock Definition
# ------------------------------------------------------------------------------
# Define the main clock with a 10ns period (50% duty cycle)
create_clock -name clk -period 10.0 -waveform {0 5.0} [get_ports clk]

# Add realism to the clock: jitter, skew, and margin
# Setup uncertainty is usually higher than hold uncertainty
set_clock_uncertainty -setup 0.2 [get_clocks clk]
set_clock_uncertainty -hold  0.1 [get_clocks clk]

# Specify the expected transition time (slew) of the clock signal
set_clock_transition 0.15 [get_clocks clk]

# ------------------------------------------------------------------------------
# 2. Input Delays
# ------------------------------------------------------------------------------
# We allocate 20% of the clock period (2.0ns) to external logic driving our inputs.
# This leaves 8.0ns for the internal flip-flop setup time and routing.
set_input_delay -max 2.0 -clock clk [get_ports {d[*] en}]
set_input_delay -min 0.5 -clock clk [get_ports {d[*] en}]

# Reset timing: Even though it's an async reset, Genus/Innovus check 
# recovery/removal timing to ensure it doesn't de-assert right on a clock edge.
set_input_delay -max 2.0 -clock clk [get_ports rst_n]

# ------------------------------------------------------------------------------
# 3. Output Delays
# ------------------------------------------------------------------------------
# We allocate 20% of the clock period (2.0ns) for external logic capturing our outputs.
set_output_delay -max 2.0 -clock clk [get_ports {q[*]}]
set_output_delay -min 0.5 -clock clk [get_ports {q[*]}]

# ------------------------------------------------------------------------------
# 4. Environment & Design Rules (DRC)
# ------------------------------------------------------------------------------
# Define the input transition (slew) arriving from upstream cells
set_input_transition 0.2 [get_ports {d[*] en rst_n}]

# Define the capacitive load the outputs must drive (e.g., 0.05 pF)
# This forces Genus to pick flip-flops with sufficient drive strength.
set_load 0.05 [get_ports {q[*]}]

# ------------------------------------------------------------------------------
# 5. Exceptions
# ------------------------------------------------------------------------------
# If rst_n is strictly asynchronous and you do NOT want the tool to spend effort 
# fixing recovery/removal timing, you can uncomment the following line. 
# However, standard practice is to synchronize resets externally and time them.
# set_false_path -from [get_ports rst_n]
